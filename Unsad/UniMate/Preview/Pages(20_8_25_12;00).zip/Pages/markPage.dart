// marks.dart - This file contains the MarksPage widget.
import 'package:flutter/material.dart';

// This is the widget for the Marks page. It displays a table with subjects and scores.
class MarksPage extends StatelessWidget {
  const MarksPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Sample data to display in the table.
    final List<Map<String, dynamic>> marksData = [
      {'subject': 'MATH 2101', 'mid': 18, 'quiz1': 9, 'quiz2': 8, 'quiz3': 7},
      {'subject': 'EEE 2141', 'mid': 17, 'quiz1': 8, 'quiz2': 8, 'quiz3': 9},
      {'subject': 'CSE 2103', 'mid': 19, 'quiz1': 9, 'quiz2': 9, 'quiz3': 8},
      {'subject': 'CSE 2105', 'mid': 18, 'quiz1': 9, 'quiz2': 9, 'quiz3': 10},
      {'subject': 'HUM 2109', 'mid': 17, 'quiz1': 8, 'quiz2': 7, 'quiz3': 9},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Marks'),
        centerTitle: true,
        backgroundColor: Colors.purple,
        elevation: 4,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Table(
            // Use the Table widget for more control over borders and dividers.
            border: TableBorder.all(
              color: Colors.grey.shade400,
              width: 1,
            ),
            children: [
              // Column headers
              TableRow(
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                ),
                children: const [
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Subject',
                        style: TextStyle(fontStyle: FontStyle.normal, fontWeight: FontWeight.bold)),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Mid',
                        style: TextStyle(fontStyle: FontStyle.normal, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Quiz 1',
                        style: TextStyle(fontStyle: FontStyle.normal, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Quiz 2',
                        style: TextStyle(fontStyle: FontStyle.normal, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Quiz 3',
                        style: TextStyle(fontStyle: FontStyle.normal, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center),
                  ),
                ],
              ),
              // Data rows
              ...marksData.map((marks) {
                return TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(marks['subject']!),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(child: Text(marks['mid'].toString())),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(child: Text(marks['quiz1'].toString())),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(child: Text(marks['quiz2'].toString())),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(child: Text(marks['quiz3'].toString())),
                    ),
                  ],
                );
              }).toList(),
            ],
          ),
        ),
      ),
    );
  }
}