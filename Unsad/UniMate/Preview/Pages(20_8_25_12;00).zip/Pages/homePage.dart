import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:unimate/presentation/Pages/dailyRoutinePage.dart';
import 'package:unimate/presentation/Pages/detailsPage.dart';
import 'package:unimate/presentation/Pages/documentsPage.dart';
import 'package:unimate/presentation/Pages/menuPage.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.more_vert, color: Colors.black),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const MenuPage()),
            );
            // 3 dot menu action
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),

            // Big Circle with CGPA -> Documents Page
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const DocumentsPage()),
                );
              },
              child: Center(
                child: Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    color: const Color(0xFFD9CF39),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.grey,
                      width: 6,
                    ),
                  ),
                  child: const Center(
                    child: Text(
                      "2.1",
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),
            const Text(
              "Fall-2024",
              style: TextStyle(
                fontSize: 22,
                fontFamily: 'Times New Roman',
                fontWeight: FontWeight.w600,
                color: Colors.brown,
              ),
            ),

            const SizedBox(height: 30),

            // Progress Section
            const TopicProgress(
              totalTopics: 12,
              completedTopics: 7,
            ),

            const SizedBox(height: 40),

            // Daily Routine Big Box
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const DailyRoutinePage()),
                );
              },
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                height: 100,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F08A),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Center(
                  child: Text(
                    "Daily Routine",
                    style: TextStyle(
                      fontSize: 22,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 80),

            // Documents & Drive Link Section (Bottom)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Documents
                  Column(
                    children: [
                      const Text(
                        "Documents",
                        style: TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 15),
                      _circleButton(context, Icons.folder, "Theory"),
                      const SizedBox(height: 20),
                      _circleButton(context, Icons.folder, "Lab"),
                    ],
                  ),

                  // Drive Link
                  Column(
                    children: [
                      const Text(
                        "Drive Link",
                        style: TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 15),
                      _circleButton(context, Icons.link, "Link"),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Reusable Circle Button
  static Widget _circleButton(BuildContext context, IconData icon, String text) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DetailPage(title: text)),
        );
      },
      child: Column(
        children: [
          CircleAvatar(
            radius: 35,
            backgroundColor: Colors.purple,
            child: Icon(icon, color: Colors.white, size: 28),
          ),
          const SizedBox(height: 8),
          Text(
            text,
            style: const TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }
}

// Topic Progress Custom Class
class TopicProgress extends StatelessWidget {
  final int totalTopics;
  final int completedTopics;

  const TopicProgress({
    super.key,
    required this.totalTopics,
    required this.completedTopics,
  });

  @override
  Widget build(BuildContext context) {
    double progress = completedTopics / totalTopics;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 40),
      height: 25,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.grey[300],
      ),
      child: Stack(
        children: [
          FractionallySizedBox(
            widthFactor: progress,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  colors: [
                    Colors.greenAccent.shade100,
                    Colors.greenAccent.shade400,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
          ),
          Center(
            child: Text(
              "$completedTopics / $totalTopics Topics Completed",
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          )
        ],
      ),
    );
  }
}