// Dummy Daily Routine Page
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DailyRoutinePage extends StatelessWidget {
  const DailyRoutinePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Daily Routine")),
      body: const Center(child: Text("Daily routine details go here")),
    );
  }
}