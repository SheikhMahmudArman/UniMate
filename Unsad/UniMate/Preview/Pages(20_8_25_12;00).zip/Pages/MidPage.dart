import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MidPage extends StatelessWidget {
  const MidPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mid')),
      body: const Center(child: Text('Mid Page')),
    );
  }
}