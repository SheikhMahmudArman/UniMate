import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class FacultyPage extends StatelessWidget {
  const FacultyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Faculty')),
      body: const Center(child: Text('Faculty Page')),
    );
  }
}