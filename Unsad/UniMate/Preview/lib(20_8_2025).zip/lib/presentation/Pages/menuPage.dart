import 'package:flutter/material.dart';

class MenuPage extends StatefulWidget {
  const MenuPage({super.key});

  @override
  _MenuPageState createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  bool _isDatesExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFFD1C4E9), // Light purple
      child: SafeArea(
        child: Column(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Color(0xFF9575CD), // Header color
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  ListTile(
                    leading: const Icon(Icons.settings, color: Colors.black),
                    title: const Text('Settings'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/settings');
                    },
                  ),
                  ExpansionTile(
                    title: const Text('Dates'),
                    leading: const Icon(Icons.calendar_today, color: Colors.black),
                    tilePadding: const EdgeInsets.symmetric(horizontal: 16.0),
                    childrenPadding: const EdgeInsets.only(left: 32.0),
                    onExpansionChanged: (bool expanded) {
                      setState(() {
                        _isDatesExpanded = expanded;
                      });
                    },
                    children: [
                      ListTile(
                        title: const Text('Quiz'),
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(context, '/quiz');
                        },
                      ),
                      ListTile(
                        title: const Text('Mid'),
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(context, '/mid');
                        },
                      ),
                      ListTile(
                        title: const Text('Final'),
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(context, '/final');
                        },
                      ),
                    ],
                  ),
                  ListTile(
                    leading: const Icon(Icons.grade, color: Colors.black),
                    title: const Text('Marks'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/marks');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.person, color: Colors.black),
                    title: const Text('Faculty'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/faculty');
                    },
                  ),
                ],
              ),
            ),

            const Divider(),
            ListTile(
              leading: const Icon(Icons.info, color: Colors.black),
              title: const Text('About'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/about');
              },
            ),
            const SizedBox(height: 16.0),
          ],
        ),
      ),
    );
  }
}
